
import "./App.css";
// import AllHotelsRoutes from "./Pages/All_Hotel/AllHotelsRoutes";
// import Navbar from './Components/Navbar';
import HomePage from './Pages/Home/HomePage';
// import { FlightRoutes } from './Pages/FlightOption/FlightRoutes';
// import HotelCheckout from './Pages/HotelCheckout/HotelCheckout';
// import HotelPaymentPage from './Pages/HotelCheckout/HotelPaymentPage';
import MainRoutes from './Pages/MainRoutes';


import PaymentModal from './Pages/FlightOption/PaymentModal/PaymentModal';
import PaymentSuccess from './Pages/FlightOption/PaymentSuccess/PaymentSuccess';


function App() {
  return (
    <>

    <MainRoutes/>
    {/* <HotelCheckout/> */}
      {/* <FligthOption /> */}
      {/* <ContactFlight /> */}
      {/* <HomePage/> */}
      {/* <Hotel/> */}
      {/* <FlightHome/> */}
     {/* <FligthOption /> */}
    {/* <HomePage/> */}
    {/* <HotelPrice/> */}
    {/* <HotelSeeAvialability/> */}
      {/* <FlightRoutes /> */}
      {/* <HotelPaymentPage/> */}

    {/* <AllHotelsRoutes /> */}
    {/* <Navbar/> */}
    {/* <PaymentModal/> */}
      {/* <PaymentSuccess/> */}



 </>
  );
}

export default App;
