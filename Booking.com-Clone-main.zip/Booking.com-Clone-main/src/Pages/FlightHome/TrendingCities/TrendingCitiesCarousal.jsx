import React from 'react'





const TrendingCitiesCarousal = () => {

   
  return (
    <div>
        <div style={{border:"1px solid teal", width:"100%",height:"300px", backgroundColor:"pink"}}>
        
        </div>
    </div>
  )
}

export default TrendingCitiesCarousal