import React from 'react'

const All_Hotels_SearchBox = () => {
  return (
    <>
    
    </>
  )
}

export default All_Hotels_SearchBox